export interface Product {
    [x: string]: any;
        id: number;
        name: string;
        price: string;
      }